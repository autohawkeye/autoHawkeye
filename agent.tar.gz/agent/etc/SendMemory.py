#! /usr/bin/env python
# coding:utf-8
import os,re,time,sys

from func import GetMemory
from func import Post
from func import Logger as log
from func import Conf as conf
from func import BaseModel

class SendMemory():

    def __init__(self):
        temp_conf = conf.Conf().get_conf()
        self.keys = BaseModel.BaseModel().getToken()
        self.ip = BaseModel.BaseModel().getLocalIp()
        self.url = temp_conf.get('server') + "/service/eyeLinux/updateMemory"

    def send_memory(self):
        try:
            memory = GetMemory.GetMemory().getAllMemory()
            memory['keys'] = self.keys
            memory['ip'] = self.ip
            Post.Post(self.url, memory).sendPostRequest()

        except:
            message = 'Send memory information is failure !!!'
            p = log.Logger(message)
            p.write_logger()

