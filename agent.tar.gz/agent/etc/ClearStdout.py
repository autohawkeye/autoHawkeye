#! /usr/bin/env python
# coding:utf-8
import time

from func import ClearLog as clearLog
from func import Logger as log
from func import Conf as conf

class ClearStdout():

    def __init__(self):
        temp_conf = conf.Conf().get_conf()
        self.filePath = temp_conf.get('logDir')
        self.large = temp_conf.get('logSize')

    def clear(self):
        try:
            clearLog.ClearLog().chearLog(self.filePath,float(self.large))
        except:
            message = 'clear log is failure !!!'
            p = log.Logger(message)
            p.write_logger()



if __name__ == '__main__':
    ClearStdout().clear()
    time.sleep(10)
