#! /usr/bin/env python
# coding:utf-8
import os,re,time,sys

from func import GetDiskIO
from func import Post
from func import Logger as log
from func import Conf as conf
from func import BaseModel
class SendDiskIO():

    def __init__(self):
        temp_conf = conf.Conf().get_conf()
        self.keys = BaseModel.BaseModel().getToken()
        self.ip = BaseModel.BaseModel().getLocalIp()
        self.url = temp_conf.get('server') + "/service/eyeLinux/updateDiskIO"

    def send_diskIO(self):
        try:
            diskIO = {}
            dataTmp = {}
            command_Device = 'iostat -dxkt|grep Device'
            command_da = "iostat -dxmt 1 3|grep vda|awk 'END {print}'"
            data_Device = GetDiskIO.GetDiskIO().getDiskIO(command_Device)['data'].strip('\n').split(' ')
            data_da = GetDiskIO.GetDiskIO().getDiskIO(command_da)['data'].strip('\n').split(' ')
            while '' in data_Device:
                data_Device.remove('')
            while '' in data_da:
                data_da.remove('')
            dataTmp = dict(zip(data_Device, data_da))
            diskIO['keys'] = self.keys
            diskIO['ip'] = self.ip
            diskIO['device']=dataTmp['Device:']
            diskIO['rkbs'] = dataTmp['rkB/s']
            diskIO['await'] = dataTmp['await']
            diskIO['ws'] = dataTmp['w/s']
            diskIO['svctm'] = dataTmp['svctm']
            diskIO['wkbs'] = dataTmp['wkB/s']
            diskIO['rs'] = dataTmp['r/s']
            diskIO['util'] = dataTmp['%util']
            Post.Post(self.url, diskIO).sendPostRequest()

        except:
            message = 'Send diskIO information is failure !!!'
            p = log.Logger(message)
            p.write_logger()




# if __name__ == '__main__':
#    SendDiskIO().send_diskIO()
