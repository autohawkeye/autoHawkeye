#! /usr/bin/env python
# coding:utf-8
import os,re,time,sys

from func import GetHost
from func import Post
from func import Logger as log
from func import Conf as conf
from func import BaseModel

class SendHost():

    def __init__(self):
        temp_conf = conf.Conf().get_conf()
        self.keys = BaseModel.BaseModel().getToken()
        self.ip = BaseModel.BaseModel().getLocalIp()
        self.url = temp_conf.get('server') + "/service/eyeLinux/updateEyeHost"
        self.memory = GetHost.GetHost().getMemory()
        self.cpuNum,self.cpuModel = GetHost.GetHost().getCpu()
        self.osVersion = GetHost.GetHost().getOsVersion()
        self.hostName = GetHost.GetHost().getHostname()
        self.agentVersion = GetHost.GetHost().getAgentVersion()
        self.totalDisk = GetHost.GetHost().gettoaldisk()

    def send_host(self):
        try:
            host = {}
            host['memory'] = self.memory
            host['cpuNum'] = self.cpuNum
            host['cpuModel'] = self.cpuModel
            host['osVersion'] = self.osVersion
            host['hostName'] = self.hostName
            host['keys'] = self.keys
            host['ip'] = self.ip
            host['agentVersion'] = self.agentVersion
            host['totalDisk'] = self.totalDisk
            Post.Post(self.url, host).sendPostRequest()

        except:
            message = 'Send host information is failure !!!'
            p = log.Logger(message)
            p.write_logger()


