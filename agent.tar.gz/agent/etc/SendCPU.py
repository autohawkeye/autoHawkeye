#! /usr/bin/env python
# coding:utf-8
import os,re,time,sys

from func import GetCPU
from func import Post
from func import Logger as log
from func import Conf as conf
from func import BaseModel

class SendCPU():

    def __init__(self):
        temp_conf = conf.Conf().get_conf()
        self.keys = BaseModel.BaseModel().getToken()
        self.ip = BaseModel.BaseModel().getLocalIp()
        self.url = temp_conf.get('server') + "/service/eyeLinux/updateCpu"

    def send_cpu(self):
        try:
            cpu = GetCPU.GetCPU().get_cpu_core()
            cpu_data = GetCPU.GetCPU().get_cpu_loadavg()
            cpu['keys'] = self.keys
            cpu['ip'] = self.ip
            dictMerged = cpu.copy()
            dictMerged.update(cpu_data)
            Post.Post(self.url, dictMerged).sendPostRequest()

        except:
            message = 'Send cpu information is failure !!!'
            p = log.Logger(message)
            p.write_logger()



