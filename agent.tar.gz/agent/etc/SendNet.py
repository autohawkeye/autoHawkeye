#! /usr/bin/env python
# coding:utf-8
import os,re,time,sys

from func import GetNetWork
from func import Post
from func import Logger as log
from func import Conf as conf
from func import BaseModel
class SendNet():

    def __init__(self):
        temp_conf = conf.Conf().get_conf()
        self.keys = BaseModel.BaseModel().getToken()
        self.ip = BaseModel.BaseModel().getLocalIp()
        self.url = temp_conf.get('server') + "/service/eyeLinux/updateNetwork"

    def send_net(self):
        try:
            net_data = GetNetWork.GetNetWork().net_loop()
            net_data['keys'] = self.keys
            net_data['ip'] = self.ip
            Post.Post(self.url, net_data).sendPostRequest()

        except:
            message = 'Send net information is failure !!!'
            p = log.Logger(message)
            p.write_logger()
