#! /usr/bin/env python
# coding:utf-8
import os,re,time,sys

from func import GetDisk
from func import Post
from func import Logger as log
from func import Conf as conf
from func import BaseModel
class SendDisk():

    def __init__(self):
        temp_conf = conf.Conf().get_conf()
        self.keys = BaseModel.BaseModel().getToken()
        self.ip = BaseModel.BaseModel().getLocalIp()
        self.url = temp_conf.get('server') + "/service/eyeLinux/updateDisk"

    def send_disk(self):
        try:
            disk = GetDisk.GetDisk().check_hd_use()
            disk['keys'] = self.keys
            disk['ip'] = self.ip
            Post.Post(self.url, disk).sendPostRequest()

        except:
            message = 'Send disk information is failure !!!'
            p = log.Logger(message)
            p.write_logger()
