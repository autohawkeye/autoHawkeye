#! /usr/bin/env python
# coding:utf-8

from func import Logger as log

class GetCPU():

    def get_cpu_core(self):
            path = '/proc/cpuinfo'
            str = 'processor'
            core = 0
            data = {}
            try:
                f = open(path, 'r')
                alllines = f.readlines()
                f.close()
                for i in alllines:
                    if i.find(str)== 0 :
                        core = core + 1
                data['cpu_cores'] = core

            except:
                message = 'Read the /proc/cpuinfo is fail !!!'
                p = log.Logger(message)
                p.write_logger()
            return data

    def get_cpu_loadavg(self):
        path = '/proc/loadavg'
        loadavg = {}
        try:
            f = open(path,'r')
            con = f.read().split()
            f.close()
            loadavg['one_load'] = con[0]
            loadavg['five_load'] = con[1]
            loadavg['fifteen_load'] = con[2]
        except:
            message = 'Read the /proc/loadavg is fail !!!'
            p = log.Logger(message)
            p.write_logger()
        return loadavg


