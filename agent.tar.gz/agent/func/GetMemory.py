#! /usr/bin/env python
# coding:utf-8

import time,socket
from func import Logger as log
from collections import OrderedDict

class GetMemory():

    def __init__(self):
        self.data = {}
        self.path = '/proc/meminfo'

    def getHost(self):
        return socket.gethostname()

    def getMemInfo(self):
        meminfo = OrderedDict()
        with open(self.path) as f:
            for line in f:
                meminfo[line.split(':')[0]] = line.split()[1].strip()
        return meminfo

    def getMemTotal(self):
        a = float(GetMemory().getMemInfo()['MemTotal'])
        return format(a / 1024 / 1024, '.2f')

    def getMemUsage(self):
        T = float(GetMemory().getMemInfo()['MemTotal'])
        F = float(GetMemory().getMemInfo()['MemFree'])
        B = float(GetMemory().getMemInfo()['Buffers'])
        C = float(GetMemory().getMemInfo()['Cached'])
        return format((T - F - B - C) / 1024 /1024, '.2f')

    def getMemFree(self):
        F = float(GetMemory().getMemInfo()['MemFree'])
        B = float(GetMemory().getMemInfo()['Buffers'])
        C = float(GetMemory().getMemInfo()['Cached'])
        return (F + B + C) / 1024 / 1024

    def getAllMemory(self):
        T = float(GetMemory().getMemInfo()['MemTotal'])
        F = float(GetMemory().getMemInfo()['MemFree'])
        B = float(GetMemory().getMemInfo()['Buffers'])
        C = float(GetMemory().getMemInfo()['Cached'])
        self.data['total_memory'] = format(T /1024/1024, '.2f')
        self.data['used_memory'] = format((T - F - B - C) / 1024/1024, '.2f')
        self.data['free_memory'] = format((F + B + C) / 1024/1024, '.2f')
        self.data['cached_memory'] = format(C /1024/1024, '.2f')
        return self.data

