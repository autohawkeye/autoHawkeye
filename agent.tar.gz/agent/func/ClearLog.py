#! /usr/bin/env python
# coding:utf-8

from func import Logger as log

import os,sys

sys.path.append("..")

class ClearLog():

    def chearLog(self,filePath,large):
        try:
            if os.path.exists(filePath):
                size = ClearLog().getfilesize(filePath)
                print size
                if size > large:
                    os.system("echo > " + filePath)
                    message = ('stdout.log %.2f M file clear is success !!!'%(size))
                    p = log.Logger(message)
                    p.write_logger()
            else:
                message = 'stdout.log file is not exists !!!'
                p = log.Logger(message)
                p.write_logger()
        except:
            message = 'clear stdout log is failure !!!'
            p = log.Logger(message)
            p.write_logger()

    def getfilesize(self,filePath):
        fsize = os.path.getsize(filePath)
        fsize = fsize / float(1024 * 1024)
        return round(fsize, 2)

