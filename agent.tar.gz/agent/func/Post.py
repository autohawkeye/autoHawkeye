#! /usr/bin/env python
# coding:utf-8


import urllib
import urllib2
import json
import time
from func import Logger


class Post():

     def __init__(self, url, data={}):
         self.url = url
         self.data = data

     def sendPostRequest(self):
         data_urlencode = urllib.urlencode(self.data)
         req = urllib2.Request(self.url, data_urlencode)

         res_data = urllib2.urlopen(req)
         res = res_data.read()
         message = self.url +' - '+ res
         Logger.Logger(message).write_logger()

     def sendPostRequestJsonToElasticsearch(self):
         headers = {'Content-Type': 'application/json'}
	 self.data['@timestamp']=time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()))
         req = urllib2.Request(self.url, headers=headers, data=json.dumps(self.data))

         res_data = urllib2.urlopen(req)
         res = res_data.read()
         message = self.url +' - '+ res
         Logger.Logger(message).write_logger()
