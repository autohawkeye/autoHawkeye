#!/usr/bin/env python
#coding:utf-8

import json
import subprocess
import time
class GetDiskIO():

    def getDiskIO(self,command):
        timeout = 60
        data = {"result": "", "msg": "", "data": ""}
        try:
            proc = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
            t_beginning = time.time()
            seconds_passed = 0
            while True:
                if proc.poll() == 0:
                    stdout, stderr = proc.communicate()
                    status = proc.returncode
                    if 0 == status:
                        data["result"] = 1
                        data["msg"] = "exec is success"
                        data["data"] = stdout
                    else:
                        data["result"] = 0
                        data["msg"] = "exec is fail"
                    break
                seconds_passed = time.time() - t_beginning
                if seconds_passed > timeout:
                    proc.kill()
                    data["result"] = 0
                    data["msg"] = "exec is timeout"
                    break
                time.sleep(1)
        except:
            data["result"] = "0"
            data["msg"] = "exec is exception"
        return data


