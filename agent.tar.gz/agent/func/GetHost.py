#!/usr/bin/env python
#coding:utf-8
from subprocess import Popen, PIPE
import os, sys
from func import BaseModel

class GetHost():

    def getlocalIp(self):
        ip = BaseModel.BaseModel().getLocalIp()
        return ip

    def getHostname(self):
        sys = os.name

        if sys == 'nt':
            hostname = os.getenv('computername')
            return hostname

        elif sys == 'posix':
            host = os.popen('echo $HOSTNAME')
            try:
                hostname = host.read()
                return hostname.strip("\n")
            finally:
                host.close()
        else:
            return 'Unkwon hostname'

    def getOsVersion(self):
        with open('/etc/redhat-release') as fd:
            for line in fd:
                osver = line.strip()
                break
        return osver

    ''' 获取CPU的型号和CPU的核心数 '''

    def getCpu(self):
        num = 0
        with open('/proc/cpuinfo') as fd:
            for line in fd:
                if line.startswith('processor'):
                    num += 1
                if line.startswith('model name'):
                    cpu_model = line.split(':')[1].strip().split()
                    cpu_model = cpu_model[0] + ' ' + cpu_model[2] + ' ' + cpu_model[-1]
        return num,cpu_model

    ''' 获取Linux系统的总物理内存 '''

    def getMemory(self):
        with open('/proc/meminfo') as fd:
            for line in fd:
                if line.startswith('MemTotal'):
                    mem = float(line.split()[1].strip())
                    break
        mem = format(float(mem) / 1024 / 1024, '.2f')
        return mem

    def getAgentVersion(self):
        return "1.0.0"

    def gettoaldisk(self):
        cmd_get_hd_use = '/bin/df -h'
        total_disk_info = os.popen(cmd_get_hd_use).readlines()
        disk_temp = total_disk_info[1].strip('\n').split(' ')
        while '' in disk_temp:
            disk_temp.remove('')
        total_disk = disk_temp[1]
        return total_disk

