#! /usr/bin/env python
# coding:utf-8

import logging,sys

class Logger():

    def __init__(self, message):
        self.log_data = message

    def write_logger(self):
        logger = logging.getLogger('mylogger')
        logger.setLevel(logging.DEBUG)
        fh = logging.FileHandler('../logs/stdout.log')
        fh.setLevel(logging.DEBUG)

        ch = logging.StreamHandler()
        ch.setLevel(logging.DEBUG)

        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

        fh.setFormatter(formatter)
        ch.setFormatter(formatter)

        logger.addHandler(fh)
        logger.addHandler(ch)
        logger.info(self.log_data)
        logger.removeHandler(fh)
        logger.removeHandler(ch)

