#/usr/bin/env python
#coding=utf-8

import sys,re,time,os

class GetNetWork():

    def __init__(self):
        self.wait_time = 5

    def get_net_data(self):
        netcard = '/proc/net/dev'
        nc = netcard or '/proc/net/dev'
        fd = open(nc, "r")
        netcardstatus = False
        for line in fd.readlines():
            if line.find("eth0") > 0:
                netcardstatus = True
                field = line.split()
                recv = field[0].split(":")[1]
                recv = recv or field[1]
                send = field[9]
        if not netcardstatus:
            fd.close()
            print 'Please setup your netcard'
            sys.exit()
        fd.close()
        return (float(recv), float(send))

    def net_loop(self):
        netSpeed = {}
        (recv, send) = GetNetWork().get_net_data()
        time.sleep(self.wait_time)
        (new_recv, new_send) = GetNetWork().get_net_data()
        recvdata = format((new_recv - recv) / 128 / self.wait_time, '.3f')
        senddata = format((new_send - send) / 128 / self.wait_time, '.3f')
        netSpeed['in_speed'] = recvdata
        netSpeed['out_speed'] = senddata
        print recvdata,senddata
        return netSpeed
