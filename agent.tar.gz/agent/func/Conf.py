#! /usr/bin/env python
# coding:utf-8

import os,re
import Logger as log

class Conf():

    def get_conf(self):

        path = '../conf/agentd.conf'
        data = {}
        try:
            f = open(path, 'r')
            alllines = f.readlines()
            f.close()
            for eachline in alllines:
                flag = eachline.find('=')
                #print flag
                if flag >=0 :
                    temp = eachline.strip().split('=')
                    data[temp[0].strip()]= temp[1].strip()
                    #print data
        except:
            message = 'Read the agentd.conf is fail !!!'
            p = log.Logger(message)
            p.write_logger()
        return data
