#! /usr/bin/env python
# coding:utf-8

from func import Logger as log

import os,re

class GetDisk():

    def check_hd_use(self):

        cmd_get_hd_use = '/bin/df -h'

        try:
            total_disk_info = os.popen(cmd_get_hd_use).readlines()
            disk_temp = total_disk_info[1].strip('\n').split(' ')
            while '' in disk_temp:
                disk_temp.remove('')
            total_disk = disk_temp[1]
            used_disk = disk_temp[2]
            avail_disk = disk_temp[3]
            rate_disk = disk_temp[4].strip('%')
        except:
            message = 'Get disk information is failure !!!'
            p = log.Logger(message)
            p.write_logger()

        hd_use = {'total_disk': total_disk, 'used_disk': used_disk, 'free_disk': avail_disk, 'disk_rate': rate_disk}
        return hd_use
