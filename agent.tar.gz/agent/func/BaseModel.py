#!/usr/bin/env python
#coding:utf-8
import socket
from func import Conf as conf

class BaseModel():

    def getLocalIp(self):
        try:
            csock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            csock.connect(('8.8.8.8', 80))
            (addr, port) = csock.getsockname()
            csock.close()
            return addr
        except socket.error:
            return "127.0.0.1"

    def getToken(self):
        data = conf.Conf().get_conf()
        token = data.get('keys')
        return token

    def isTrueToken(self,token):
        data = conf.Conf().get_conf()
        keys = data.get('keys')
        if keys == token:
            return True
        else:
            return False

